import React from 'react'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Menu from '@mui/material/Menu'
import MenuItem from '@mui/material/MenuItem'
import Fade from '@mui/material/Fade'
import ListItemText from '@mui/material/ListItemText'
import ListItemIcon from '@mui/material/ListItemIcon'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import TopicIcon from '@mui/icons-material/Topic'
import ViewKanbanIcon from '@mui/icons-material/ViewKanban'
import Typography from '@mui/material/Typography'

function Templates() {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const open = Boolean(anchorEl)

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const handleSelectTemplate = (templateType) => {
    console.log('Selected Template:', templateType)
    handleClose()
    // Add your logic here
  }

  return (
    <Box>
      <Button
        sx={{
          color: 'white',
          textTransform: 'none',
          fontWeight: 'bold',
          px: 2,
          borderRadius: 2,
          '&:hover': {
            backgroundColor: 'rgba(255, 255, 255, 0.1)'
          }
        }}
        id="basic-button-templates"
        aria-controls={open ? 'basic-menu-templates' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
        endIcon={<ExpandMoreIcon />}
      >
        Templates
      </Button>
      <Menu
        id="basic-menu-templates"
        MenuListProps={{ 'aria-labelledby': 'basic-button-templates' }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
        PaperProps={{
          sx: {
            mt: 1.5,
            borderRadius: 2,
            minWidth: 220,
            boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
          }
        }}
      >
        <MenuItem
          onClick={() => handleSelectTemplate('big-topic')}
          sx={{
            px: 2,
            py: 1.5,
            '&:hover': { backgroundColor: 'primary.light', color: 'white' }
          }}
        >
          <ListItemIcon>
            <TopicIcon fontSize="medium" />
          </ListItemIcon>
          <ListItemText
            primary={<Typography fontWeight="medium">Big Topic Template</Typography>}
            secondary="Group tasks by themes"
          />
        </MenuItem>

        <MenuItem
          onClick={() => handleSelectTemplate('kanban')}
          sx={{
            px: 2,
            py: 1.5,
            '&:hover': { backgroundColor: 'primary.light', color: 'white' }
          }}
        >
          <ListItemIcon>
            <ViewKanbanIcon fontSize="medium" />
          </ListItemIcon>
          <ListItemText
            primary={<Typography fontWeight="medium">Kanban Template</Typography>}
            secondary="To Do / Doing / Done"
          />
        </MenuItem>
      </Menu>
    </Box>
  )
}

export default Templates
