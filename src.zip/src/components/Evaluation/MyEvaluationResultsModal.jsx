// MyEvaluationResultsModal.js - Xem điểm đánh giá của bản thân
import React, { useEffect, useState, useMemo } from 'react'
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  Button,
  Rating,
  Divider,
  Chip,
  Alert,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  LinearProgress
} from '@mui/material'
import {
  Star,
  StarBorder,
  Person,
  TrendingUp,
  Assessment,
  EmojiEvents
} from '@mui/icons-material'
import { useDispatch, useSelector } from 'react-redux'
import { toast } from 'react-toastify'

import {
  fetchMyEvaluationResultsThunk,
  selectMyEvaluationResults,
  selectResultsLoading
} from '~/redux/activeEvaluationSubmission/myEvaluationResultsSlice'
import {
  fetchEvaluationCriteriaThunk,
  selectEvaluationCriteria
} from '~/redux/activeEvaluation/activeEvaluationSlice'
import { selectCurrentUser } from '~/redux/User/userSlice'

const MyEvaluationResultsModal = ({ open, onClose, board }) => {
  const dispatch = useDispatch()
  const currentUser = useSelector(selectCurrentUser)
  const myResults = useSelector(selectMyEvaluationResults)
  const loading = useSelector(selectResultsLoading)
  const criteria = useSelector(selectEvaluationCriteria)

  const [hasFetched, setHasFetched] = useState(false)

  // Fetch dữ liệu khi modal mở
  useEffect(() => {
    if (open && board?._id && currentUser?._id) {
      console.log('🔄 Fetching my evaluation results for board:', board._id)

      // Fetch criteria và results song song
      Promise.all([
        dispatch(fetchEvaluationCriteriaThunk(board._id)),
        dispatch(fetchMyEvaluationResultsThunk({
          boardId: board._id,
          userId: currentUser._id
        }))
      ])
        .then(() => {
          setHasFetched(true)
          console.log('✅ Successfully fetched evaluation data')
        })
        .catch((error) => {
          console.error('❌ Error fetching evaluation data:', error)
          toast.error('Có lỗi khi tải dữ liệu đánh giá', { theme: 'colored' })
        })
    }
  }, [open, board?._id, currentUser?._id, dispatch])

  // Reset state khi đóng modal
  useEffect(() => {
    if (!open) {
      setHasFetched(false)
    }
  }, [open])

  // Xử lý dữ liệu đánh giá
  const processedResults = useMemo(() => {
    if (!myResults || !Array.isArray(myResults) || myResults.length === 0) {
      return {
        evaluations: [],
        totalEvaluators: 0,
        averageScores: {},
        overallAverage: 0,
        criteriaStats: {}
      }
    }

    const validEvaluations = myResults.filter(e =>
      e && e.ratings && Array.isArray(e.ratings)
    )

    // Tính điểm trung bình theo từng tiêu chí
    const criteriaScores = {}
    const criteriaStats = {}

    validEvaluations.forEach(evaluation => {
      evaluation.ratings
        .filter(rating => rating) // 🔧 Lọc undefined
        .forEach(rating => {
          const criterionId = rating.criterion?.toString() || rating.criterion
          if (!criteriaScores[criterionId]) {
            criteriaScores[criterionId] = []
          }
          criteriaScores[criterionId].push(rating.score)
        })
    })

    // Tính trung bình và thống kê cho từng tiêu chí
    const averageScores = {}
    Object.keys(criteriaScores).forEach(criterionId => {
      const scores = criteriaScores[criterionId]
      const average = scores.reduce((sum, score) => sum + score, 0) / scores.length
      averageScores[criterionId] = average

      criteriaStats[criterionId] = {
        average: Math.round(average * 10) / 10,
        count: scores.length,
        min: Math.min(...scores),
        max: Math.max(...scores),
        scores: scores
      }
    })

    // Tính điểm trung bình tổng thể
    const allScores = Object.values(criteriaScores).flat()
    const overallAverage = allScores.length > 0
      ? allScores.reduce((sum, score) => sum + score, 0) / allScores.length
      : 0

    return {
      evaluations: validEvaluations,
      totalEvaluators: validEvaluations.length,
      averageScores,
      overallAverage: Math.round(overallAverage * 10) / 10,
      criteriaStats
    }
  }, [myResults])

  // Lấy thông tin người đánh giá
  const getEvaluatorInfo = (evaluatorId) => {
    if (!board?.FE_allUsers) return { name: 'Không xác định', avatar: null }

    const evaluator = board.FE_allUsers.find(user =>
      user._id?.toString() === evaluatorId?.toString()
    )

    return {
      name: evaluator?.displayName || evaluator?.username || 'Không xác định',
      avatar: evaluator?.avatar || null
    }
  }

  // Lấy thông tin tiêu chí
  const getCriterionInfo = (criterionId) => {
    if (!criteria || !Array.isArray(criteria)) return { title: 'Không xác định', description: '' }

    const criterion = criteria.find(c =>
      c._id?.toString() === criterionId?.toString()
    )

    return {
      title: criterion?.title || criterion?.name || 'Không xác định', // Ưu tiên title trước
      description: criterion?.description || ''
    }
  }

  // Render điểm số với màu sắc
  const renderScoreChip = (score) => {
    let color = 'default'
    if (score >= 4.5) color = 'success'
    else if (score >= 3.5) color = 'primary'
    else if (score >= 2.5) color = 'warning'
    else color = 'error'

    return (
      <Chip
        label={`${score}/5`}
        color={color}
        size="small"
        icon={<Star />}
      />
    )
  }

  if (loading) {
    return (
      <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
        <DialogContent>
          <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
            <CircularProgress />
            <Typography sx={{ ml: 2 }}>Đang tải kết quả đánh giá...</Typography>
          </Box>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: { minHeight: '600px' }
      }}
    >
      <DialogTitle>
        <Box display="flex" alignItems="center" gap={1}>
          <Assessment color="primary" />
          <Typography variant="h6">
            📊 Kết quả đánh giá của tôi - {board?.title}
          </Typography>
        </Box>
      </DialogTitle>

      <DialogContent>
        {processedResults.totalEvaluators === 0 ? (
          <Alert severity="info" sx={{ mt: 2 }}>
            <Typography>
              Bạn chưa được ai đánh giá trong board này.
              Hãy đợi các thành viên khác hoàn thành đánh giá!
            </Typography>
          </Alert>
        ) : (
          <Grid container spacing={3}>
            {/* Tổng quan */}
            <Grid item xs={12}>
              <Card variant="outlined" sx={{ bgcolor: 'primary.50' }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    🏆 Tổng quan kết quả
                  </Typography>
                  <Grid container spacing={3}>
                    <Grid item xs={6} sm={3}>
                      <Box textAlign="center">
                        <Typography variant="h3" color="primary.main">
                          {processedResults.totalEvaluators}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          Người đánh giá
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Box textAlign="center">
                        <Typography variant="h3" color="success.main">
                          {processedResults.overallAverage}
                        </Typography>
                        <Typography variant="body2" color="textSecondary">
                          Điểm trung bình
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Box textAlign="center">
                        <Rating
                          value={processedResults.overallAverage}
                          readOnly
                          precision={0.1}
                          emptyIcon={<StarBorder />}
                          icon={<Star />}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Box textAlign="center">
                        <EmojiEvents
                          sx={{
                            fontSize: 40,
                            color: processedResults.overallAverage >= 4 ? 'gold' :
                              processedResults.overallAverage >= 3 ? 'silver' : 'bronze'
                          }}
                        />
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>

            {/* Điểm theo từng tiêu chí */}
            <Grid item xs={12}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    📈 Điểm theo từng tiêu chí
                  </Typography>
                  {Object.entries(processedResults.criteriaStats).map(([criterionId, stats]) => {
                    const criterionInfo = getCriterionInfo(criterionId)
                    return (
                      <Box key={criterionId} sx={{ mb: 3 }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                          <Typography variant="subtitle1" fontWeight="bold">
                            {criterionInfo.title} {/* Sửa từ name sang title */}
                          </Typography>
                          {renderScoreChip(stats.average)}
                        </Box>

                        {criterionInfo.description && (
                          <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                            {criterionInfo.description}
                          </Typography>
                        )}

                        <Box sx={{ mb: 1 }}>
                          <LinearProgress
                            variant="determinate"
                            value={(stats.average / 5) * 100}
                            sx={{
                              height: 8,
                              borderRadius: 4,
                              bgcolor: 'grey.200',
                              '& .MuiLinearProgress-bar': {
                                bgcolor: stats.average >= 4 ? 'success.main' :
                                  stats.average >= 3 ? 'primary.main' :
                                    stats.average >= 2 ? 'warning.main' : 'error.main'
                              }
                            }}
                          />
                        </Box>

                        <Box display="flex" gap={2} sx={{ fontSize: '0.875rem', color: 'text.secondary' }}>
                          <span>Trung bình: <strong>{stats.average}/5</strong></span>
                          <span>Cao nhất: <strong>{stats.max}/5</strong></span>
                          <span>Thấp nhất: <strong>{stats.min}/5</strong></span>
                          <span>Số đánh giá: <strong>{stats.count}</strong></span>
                        </Box>
                      </Box>
                    )
                  })}
                </CardContent>
              </Card>
            </Grid>

            {/* Chi tiết từng đánh giá */}
            <Grid item xs={12}>
              <Card variant="outlined">
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    📝 Chi tiết đánh giá từ từng thành viên
                  </Typography>
                  <List>
                    {processedResults.evaluations.map((evaluation, index) => {
                      const evaluatorInfo = getEvaluatorInfo(evaluation.evaluator || evaluation.evaluatorId)
                      return (
                        <React.Fragment key={evaluation._id || index}>
                          <ListItem alignItems="flex-start">
                            <ListItemAvatar>
                              <Avatar src={evaluatorInfo.avatar}>
                                <Person />
                              </Avatar>
                            </ListItemAvatar>
                            <ListItemText
                              primary={
                                <Box display="flex" alignItems="center" gap={1}>
                                  <Typography variant="subtitle1" fontWeight="bold">
                                    {evaluatorInfo.name}
                                  </Typography>
                                  <Typography variant="caption" color="textSecondary">
                                    {new Date(evaluation.createdAt).toLocaleDateString('vi-VN')}
                                  </Typography>
                                </Box>
                              }
                              secondary={
                                <Box sx={{ mt: 1 }}>
                                  {evaluation.ratings?.map((rating, ratingIndex) => {
                                    const criterionInfo = getCriterionInfo(rating.criterion)
                                    return (
                                      <Box key={ratingIndex} sx={{ mb: 1 }}>
                                        <Box display="flex" justifyContent="space-between" alignItems="center">
                                          <Typography variant="body2">
                                            {criterionInfo.title}
                                          </Typography>
                                          <Box display="flex" alignItems="center" gap={1}>
                                            <Rating
                                              value={rating.score}
                                              readOnly
                                              size="small"
                                              emptyIcon={<StarBorder fontSize="small" />}
                                              icon={<Star fontSize="small" />}
                                            />
                                            <Typography variant="caption">
                                              ({rating.score}/5)
                                            </Typography>
                                          </Box>
                                        </Box>
                                      </Box>
                                    )
                                  })}
                                </Box>
                              }
                            />
                          </ListItem>
                          {index < processedResults.evaluations.length - 1 && <Divider variant="inset" component="li" />}
                        </React.Fragment>
                      )
                    })}
                  </List>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} variant="contained">
          Đóng
        </Button>
      </DialogActions>
    </Dialog>
  )
}

export default MyEvaluationResultsModal